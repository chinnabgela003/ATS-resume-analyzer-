import { PDFParse } from "pdf-parse";
import fs from "fs";

async function test() {
  try {
    console.log("PDFParse type:", typeof PDFParse);
    if (typeof PDFParse !== "function") {
      console.log("PDFParse is not a constructor/function!");
    } else {
      console.log("PDFParse is a function/constructor.");
    }
  } catch (e) {
    console.error("Test failed:", e);
  }
}

test();
