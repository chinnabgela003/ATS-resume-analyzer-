import express from "express";
import { createServer as createViteServer } from "vite";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import * as mammoth from "mammoth";
import { PDFParse } from "pdf-parse";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log("Server file loaded. PDFParse type:", typeof PDFParse);

async function startServer() {
  console.log("startServer called");
  const app = express();
  const PORT = 3000;

  console.log("Starting server in", process.env.NODE_ENV || "development", "mode");

  app.use(cors());
  app.use(express.json());

  // Health check route
  app.get("/api/health", (req, res) => {
    console.log("Health check requested");
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  console.log("Initializing multer");
  const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
  });

  // API Route for text extraction
  app.post("/api/extract-text", (req, res, next) => {
    console.log("POST /api/extract-text received");
    next();
  }, upload.single("file"), async (req, res) => {
    console.log("Multer finished processing file");
    try {
      if (!req.file) {
        console.log("No file in request after multer");
        return res.status(400).json({ error: "No file uploaded" });
      }

      console.log("File received:", req.file.originalname, req.file.mimetype, "Size:", req.file.size);
      let text = "";
      const buffer = req.file.buffer;
      const mimetype = req.file.mimetype;

      if (mimetype === "application/pdf") {
        console.log("Parsing PDF...");
        try {
          // Try the class-based approach first (as seen in the bundled code)
          console.log("Attempting PDFParse class approach");
          const parser = new PDFParse({ data: buffer });
          const result = await parser.getText();
          text = result.text;
          await parser.destroy();
          console.log("PDF parsing successful via class");
        } catch (classErr: any) {
          console.warn("PDFParse class approach failed:", classErr.message);
          try {
            // Try the function-based approach (standard pdf-parse style)
            console.log("Attempting PDFParse function approach");
            const result = await (PDFParse as any)(buffer);
            text = result.text || result;
            console.log("PDF parsing successful via function");
          } catch (funcErr: any) {
            console.error("PDF parsing failed completely:", funcErr.message);
            throw new Error(`PDF parsing failed: ${funcErr.message}`);
          }
        }
      } else if (
        mimetype === "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      ) {
        console.log("Parsing DOCX...");
        const result = await mammoth.extractRawText({ buffer });
        text = result.value;
        console.log("DOCX parsing successful");
      } else {
        console.log("Unsupported mimetype:", mimetype);
        return res.status(400).json({ error: "Unsupported file type. Please upload PDF or DOCX (Word 2007+)." });
      }

      console.log("Extraction successful, text length:", text.length);
      res.json({ text });
    } catch (error: any) {
      console.error("Extraction error details:", error);
      res.status(500).json({ error: `Failed to extract text: ${error.message || 'Unknown error'}` });
    }
  });

  // Catch-all for unmatched API routes
  app.all("/api/*", (req, res) => {
    console.log(`Unmatched API request: ${req.method} ${req.url}`);
    res.status(404).json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // Global error handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("Global server error:", err);
    res.status(500).json({ error: "Internal server error" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    console.log("Initializing Vite middleware");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static files from dist");
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

console.log("Calling startServer");
startServer().catch(err => {
  console.error("Failed to start server:", err);
});
