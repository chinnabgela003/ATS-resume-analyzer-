import React, { useState, useEffect } from "react";
import { FileUpload } from "./components/FileUpload";
import { AnalysisResult } from "./components/AnalysisResult";
import { analyzeResume } from "./services/gemini";
import { AnalysisResult as AnalysisResultType } from "./types";
import { Brain, FileSearch, Sparkles, Loader2, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [jobDescription, setJobDescription] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [loadingStep, setLoadingStep] = useState<"extracting" | "analyzing" | null>(null);
  const [result, setResult] = useState<AnalysisResultType | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check if backend is reachable
    fetch("/api/health")
      .then(res => {
        if (!res.ok) throw new Error("Backend not responding correctly");
        return res.json();
      })
      .then(data => console.log("Backend connected:", data))
      .catch(err => {
        console.error("Backend connection error:", err);
        // We don't block the UI here, just log it. 
        // The error will be more apparent when they try to analyze.
      });
  }, []);

  const handleAnalyze = async () => {
    if (!file || !jobDescription.trim()) {
      setError("Please provide both a resume and a job description.");
      return;
    }

    setIsAnalyzing(true);
    setLoadingStep("extracting");
    setError(null);
    setResult(null);

    try {
      // 1. Extract text from file via backend
      const formData = new FormData();
      formData.append("file", file);

      const extractResponse = await fetch("/api/extract-text", {
        method: "POST",
        body: formData,
      });

      console.log("Extraction response status:", extractResponse.status);
      const contentType = extractResponse.headers.get("content-type");
      console.log("Extraction response content-type:", contentType);

      if (!extractResponse.ok) {
        if (contentType && contentType.includes("application/json")) {
          const errData = await extractResponse.json();
          throw new Error(errData.error || `Extraction failed with status ${extractResponse.status}`);
        } else {
          const text = await extractResponse.text();
          console.error("Server error response:", text.substring(0, 500));
          throw new Error(`The server encountered an error (${extractResponse.status}). This usually means the file is too large or the server crashed.`);
        }
      }

      const { text: resumeText } = await extractResponse.json();
      
      setLoadingStep("analyzing");

      // 2. Analyze with Gemini
      const analysisResult = await analyzeResume(resumeText, jobDescription);
      setResult(analysisResult);
    } catch (err: any) {
      console.error("Analysis error:", err);
      setError(err.message || "An unexpected error occurred during analysis.");
    } finally {
      setIsAnalyzing(false);
      setLoadingStep(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Background Decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-indigo-200/20 blur-[120px] rounded-full" />
        <div className="absolute top-[20%] -right-[5%] w-[30%] h-[30%] bg-emerald-200/10 blur-[100px] rounded-full" />
      </div>

      <header className="relative z-10 pt-12 pb-8 px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold uppercase tracking-widest mb-6"
        >
          <Sparkles className="w-3.5 h-3.5" />
          AI-Powered Optimization
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-slate-900 mb-4">
          ATS Resume <span className="text-indigo-600">Optimizer</span>
        </h1>
        <p className="text-lg text-slate-500 max-w-2xl mx-auto">
          Upload your resume and the job description to get an instant ATS compatibility score and actionable feedback.
        </p>
      </header>

      <main className="relative z-10 container mx-auto px-6 pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Input Section */}
          <div className="lg:col-span-5 space-y-8">
            <section className="space-y-4">
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 uppercase tracking-wider">
                <FileSearch className="w-4 h-4 text-indigo-600" />
                1. Upload Resume
              </label>
              <FileUpload onFileSelect={setFile} isLoading={isAnalyzing} />
            </section>

            <section className="space-y-4">
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 uppercase tracking-wider">
                <Brain className="w-4 h-4 text-indigo-600" />
                2. Job Description
              </label>
              <textarea
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                placeholder="Paste the job description here..."
                className="w-full h-64 p-6 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-none text-sm leading-relaxed"
                disabled={isAnalyzing}
              />
            </section>

            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !file || !jobDescription.trim()}
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:shadow-none active:scale-[0.98] flex items-center justify-center gap-3"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  {loadingStep === "extracting" ? "Extracting Text..." : "Analyzing..."}
                </>
              ) : (
                "Analyze Compatibility"
              )}
            </button>

            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="p-4 bg-rose-50 border border-rose-100 rounded-xl flex items-start gap-3 text-rose-700 text-sm"
                >
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  {error}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              {result ? (
                <AnalysisResult key="result" result={result} />
              ) : isAnalyzing ? (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-12 bg-white rounded-3xl border border-slate-200 border-dashed"
                >
                  <div className="relative mb-8">
                    <div className="absolute inset-0 bg-indigo-100 rounded-full animate-ping opacity-20" />
                    <div className="relative p-6 bg-indigo-50 rounded-full">
                      {loadingStep === "extracting" ? (
                        <FileSearch className="w-12 h-12 text-indigo-600" />
                      ) : (
                        <Brain className="w-12 h-12 text-indigo-600" />
                      )}
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">
                    {loadingStep === "extracting" ? "Extracting Resume Text" : "Analyzing with AI"}
                  </h3>
                  <p className="text-slate-500 max-w-xs mx-auto">
                    {loadingStep === "extracting" 
                      ? "Reading your file and preparing data for analysis..." 
                      : "Matching your skills against the job requirements..."}
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-12 bg-slate-50 rounded-3xl border border-slate-200 border-dashed"
                >
                  <div className="p-6 bg-white rounded-full shadow-sm mb-6">
                    <Sparkles className="w-12 h-12 text-slate-300" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-400 mb-2">Ready for Analysis</h3>
                  <p className="text-slate-400 max-w-xs mx-auto">
                    Fill in the details on the left to see your ATS compatibility score.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      <footer className="relative z-10 py-12 border-t border-slate-200 text-center">
        <p className="text-sm text-slate-400">
          © {new Date().getFullYear()} ATS Resume Optimizer. Built with Gemini AI.
        </p>
      </footer>
    </div>
  );
}
