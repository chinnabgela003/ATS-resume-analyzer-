export interface ResumeData {
  name: string;
  email: string;
  phone: string;
  skills: string[];
  education: string[];
  experience: string[];
}

export interface AnalysisResult {
  score: number;
  strength: "Weak" | "Good" | "Strong";
  missingKeywords: string[];
  suggestions: string[];
  parsedResume: ResumeData;
  matchDetails: string;
}

export interface ExtractionResponse {
  text: string;
  error?: string;
}
