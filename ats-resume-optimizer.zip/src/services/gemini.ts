import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { AnalysisResult } from "../types";

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeResume(resumeText: string, jobDescription: string): Promise<AnalysisResult> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    ATS Analysis Task:
    Resume: ${resumeText.substring(0, 8000)}
    Job: ${jobDescription.substring(0, 4000)}
    
    1. Extract: Name, Email, Phone, Skills, Education, Experience.
    2. Score: 0-100 ATS compatibility.
    3. Identify: Missing keywords, Improvement suggestions.
    4. Strength: Weak/Good/Strong.
  `;

  const response = await genAI.models.generateContent({
    model,
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          strength: { type: Type.STRING },
          missingKeywords: { type: Type.ARRAY, items: { type: Type.STRING } },
          suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
          matchDetails: { type: Type.STRING },
          parsedResume: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              email: { type: Type.STRING },
              phone: { type: Type.STRING },
              skills: { type: Type.ARRAY, items: { type: Type.STRING } },
              education: { type: Type.ARRAY, items: { type: Type.STRING } },
              experience: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["name", "email", "phone", "skills", "education", "experience"]
          }
        },
        required: ["score", "strength", "missingKeywords", "suggestions", "parsedResume", "matchDetails"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("The AI failed to generate a response. Please try again.");

  try {
    // Attempt to parse directly
    return JSON.parse(text) as AnalysisResult;
  } catch (e) {
    // Fallback: Try to extract JSON from markdown blocks if present
    const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || text.match(/```\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1]) as AnalysisResult;
      } catch (innerE) {
        console.error("Failed to parse extracted JSON:", jsonMatch[1]);
      }
    }
    console.error("Raw AI response that failed to parse:", text);
    throw new Error("The AI returned an invalid response format. Please try again.");
  }
}
