import React from "react";
import { CheckCircle2, AlertCircle, TrendingUp, TrendingDown, Target, Lightbulb, User, Briefcase, GraduationCap } from "lucide-react";
import { motion } from "motion/react";
import { AnalysisResult as AnalysisResultType } from "../types";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface AnalysisResultProps {
  result: AnalysisResultType;
}

export const AnalysisResult: React.FC<AnalysisResultProps> = ({ result }) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-600 bg-emerald-50 border-emerald-100";
    if (score >= 60) return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-rose-600 bg-rose-50 border-rose-100";
  };

  const getStrengthIcon = (strength: string) => {
    if (strength === "Strong") return <TrendingUp className="w-5 h-5 text-emerald-600" />;
    if (strength === "Good") return <TrendingUp className="w-5 h-5 text-amber-600" />;
    return <TrendingDown className="w-5 h-5 text-rose-600" />;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 max-w-4xl mx-auto pb-12"
    >
      {/* Score Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={cn("p-8 rounded-3xl border-2 flex flex-col items-center justify-center text-center", getScoreColor(result.score))}>
          <span className="text-sm font-bold uppercase tracking-widest mb-2 opacity-70">ATS Score</span>
          <div className="text-6xl font-black mb-2">{result.score}%</div>
          <div className="flex items-center gap-2 font-semibold">
            {getStrengthIcon(result.strength)}
            <span>{result.strength} Profile</span>
          </div>
        </div>

        <div className="md:col-span-2 p-8 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-center">
          <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-indigo-600" />
            {result.parsedResume.name || "Candidate Profile"}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-slate-600">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-900">Email:</span> {result.parsedResume.email}
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-900">Phone:</span> {result.parsedResume.phone}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Missing Keywords */}
        <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Target className="w-5 h-5 text-rose-500" />
            Missing Keywords
          </h3>
          <div className="flex flex-wrap gap-2">
            {result.missingKeywords.length > 0 ? (
              result.missingKeywords.map((keyword, i) => (
                <span key={i} className="px-3 py-1.5 bg-rose-50 text-rose-700 text-xs font-semibold rounded-full border border-rose-100">
                  {keyword}
                </span>
              ))
            ) : (
              <p className="text-sm text-slate-500 italic">No missing keywords found! Great job.</p>
            )}
          </div>
        </div>

        {/* Suggestions */}
        <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-500" />
            Improvement Suggestions
          </h3>
          <ul className="space-y-4">
            {result.suggestions.map((suggestion, i) => (
              <li key={i} className="flex gap-3 text-sm text-slate-600">
                <div className="mt-1 shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </div>
                {suggestion}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Skills & Experience */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="p-8 bg-slate-900 text-white rounded-3xl shadow-xl">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-400" />
            Extracted Skills
          </h3>
          <div className="flex flex-wrap gap-2">
            {result.parsedResume.skills.map((skill, i) => (
              <span key={i} className="px-3 py-1.5 bg-white/10 text-indigo-100 text-xs font-medium rounded-lg border border-white/10">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="p-8 bg-white rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            Education & Experience
          </h3>
          <div className="space-y-6">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Experience Highlights</h4>
              <ul className="space-y-2">
                {result.parsedResume.experience.slice(0, 3).map((exp, i) => (
                  <li key={i} className="text-sm text-slate-600 line-clamp-2">• {exp}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Education</h4>
              <ul className="space-y-2">
                {result.parsedResume.education.map((edu, i) => (
                  <li key={i} className="text-sm text-slate-600">• {edu}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
